
import React from 'react';

interface HeaderProps {
  currentUser: string | null;
}

const Header: React.FC<HeaderProps> = ({ currentUser }) => {
  return (
    <header className="bg-gray-900 border-b-4 border-yellow-500 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 md:gap-4">
          <div className="text-center md:text-left w-full md:w-auto">
            <h1 id="app-title" className="text-2xl md:text-3xl font-bold text-white leading-tight">
              Generator Administrasi Guru &amp; Bank Soal Adaptif
            </h1>
            <p className="text-yellow-200 mt-2 text-sm md:text-base">
              Wujudkan Pembelajaran Inovatif dengan Perangkat Ajar Cerdas Berbasis AI
            </p>
          </div>
          <div className="text-center md:text-right w-full md:w-auto">
            {currentUser ? (
              <>
                <p id="welcome-message" className="text-white font-semibold text-lg">
                  Selamat Datang, {currentUser}!
                </p>
                <p className="text-yellow-200 text-sm mt-1">Berbasis Deep Learning &amp; AI</p>
              </>
            ) : (
              <>
                <p id="institution-name" className="text-white font-semibold text-sm md:text-base leading-snug">
                  YAYASAN PENDIDIKAN ISLAM PONDOK MODERN AL-GHOZALI
                </p>
                <p className="text-yellow-200 text-xs md:text-sm mt-1">Berbasis Deep Learning &amp; AI</p>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
