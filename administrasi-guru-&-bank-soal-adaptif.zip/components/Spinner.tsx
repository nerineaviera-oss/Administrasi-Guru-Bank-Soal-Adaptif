
import React from 'react';

const Spinner: React.FC = () => {
  return <div className="loading-spinner"></div>;
};

export default Spinner;