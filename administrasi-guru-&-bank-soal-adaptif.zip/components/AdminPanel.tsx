
import React, { useState } from 'react';
import { ShareableLink } from '../types';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  links: ShareableLink[];
  onAddLink: (userName: string) => void;
  onDeleteLink: (id: string) => void;
  onBackupData: () => void;
  onRestoreData: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onAddTeachers: (teachers: string[]) => void;
}

type AdminTab = 'performanceReport' | 'tracking' | 'dataManagement';

const reportHtml = `
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan Kinerja Guru 2025/2026</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      box-sizing: border-box;
      background: #eef2f6; 
      font-family: 'Segoe UI', Arial, sans-serif; 
      margin: 0;
      height: 100%;
    }
    html { height: 100%; }
    .wrap { 
      max-width: 750px; 
      background: #fff; 
      margin: 42px auto; 
      border-radius:18px; 
      box-shadow:0 8px 32px #aaadbbc9; 
      padding:32px 28px; 
    }
    .kop { 
      border-bottom: 3px solid #345; 
      text-align: center; 
      padding-bottom: 10px; 
      margin-bottom: 12px;
    }
    .kop1 { font-size: 1.09em; font-weight:600;}
    .kop2 { font-size: 1.1em; font-weight:700; margin-top: 2px;}
    .judul {font-size:1.18em; font-weight:bold; margin-top:7px; }
    .data-guru { margin-top:20px; margin-bottom: 4px;}
    .data-guru td { padding:5px 11px 2px 2px; border:none;}
    label {font-weight:600; margin-right: 7px;}
    select, input[type="text"], input[type="number"] {
      padding: 5px 7px; 
      font-size: 1em;
      border:1.1px solid #ccc; 
      border-radius: 4px; 
      background:#f6f9ff;
      margin-top: 2px; 
      margin-bottom: 2px;
    }
    table.tabel-nilai {
      width:100%; 
      border-collapse: collapse; 
      margin-top:16px; 
      margin-bottom:12px;
    }
    table.tabel-nilai th, table.tabel-nilai td {
      border: 2px solid #222; 
      padding:8px 6px; 
      text-align:center; 
      font-size:1em;
    }
    table.tabel-nilai th {
      background: #e7eefa; 
      font-weight: 700;
    }
    table.tabel-nilai tr:last-child td {
      font-weight:700; 
      background:#f8f8fb;
      border-top: 3.7px double #222;
    }
    .footer {margin-top:30px;}
    .ttd-row {
      display:flex; 
      justify-content:space-between; 
      align-items:flex-start; 
      margin-top:30px; 
      padding:0 25px;
    }
    .ttd-block {text-align:center; min-width: 200px;}
    .ttd-space { height: 80px; }
    .export-btn {
      background:#254c8d; 
      color:#fff; 
      padding:9px 26px; 
      border:none; 
      border-radius:6px; 
      font-weight:600; 
      font-size:1em; 
      margin:18px auto 0;
      display:block; 
      cursor:pointer;
    }
    .export-btn:hover { background: #3d7be7; }
    .tindak {font-size:0.98em; padding: 6px 0;}
    .field-wrap { display:inline-block; min-width: 80px;}
    .nInput { width: 60px; }
    .catatan-section {
      margin-top: 20px;
      padding: 15px;
      background: #f9f9f9;
      border-radius: 8px;
      border: 1px solid #ddd;
    }
    .catatan-section label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
    }
    .catatan-section textarea {
      width: 100%;
      min-height: 80px;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-family: inherit;
      resize: vertical;
    }
    @media (max-width:700px){
      .wrap{padding:12px 1vw}
      .ttd-row { flex-direction: column; gap: 30px; }
    }
  </style>
</head>
<body>
<div class="wrap">
  <div class="kop">
    <div class="kop1">YAYASAN PENDIDIKAN ISLAM PONDOK MODERN AL-GHOZALI<br>UNIT SMP DAN SMA ISLAM AL-GHOZALI</div>
    <div class="judul">Laporan Kinerja Guru 2025/2026</div>
  </div>
  
  <form id="raportForm" autocomplete="off">
    <table class="data-guru">
      <tr>
        <td><label for="nama">Nama Guru</label></td>
        <td><input type="text" id="nama" required></td>
        <td><label for="nik">NIK/NUPTK</label></td>
        <td><input type="text" id="nik" style="width:150px;"></td>
      </tr>
      <tr>
        <td><label for="jabatan">Jabatan</label></td>
        <td><input type="text" id="jabatan" placeholder="Guru Mapel"></td>
        <td><label for="unit">Unit</label></td>
        <td>
          <select id="unit">
            <option>SMP ISLAM AL-GHOZALI</option>
            <option>SMA ISLAM AL-GHOZALI</option>
          </select>
        </td>
      </tr>
    </table>
    
    <table class="tabel-nilai">
      <tr>
        <th rowspan="2">No</th>
        <th rowspan="2">Komponen<br>Penilaian</th>
        <th rowspan="2">Skor Minimum</th>
        <th colspan="2">Nilai</th>
        <th rowspan="2">Predikat</th>
      </tr>
      <tr>
        <th>Angka</th>
        <th>Huruf</th>
      </tr>
      <tr>
        <td>1</td>
        <td>Pedagogik</td>
        <td>70</td>
        <td><input type="number" class="nInput" id="pedagogik" min="0" max="100" value="70" required></td>
        <td class="huruf" id="pedagogik_huruf">B</td>
        <td id="predikat_pedagogik">Baik</td>
      </tr>
      <tr>
        <td>2</td>
        <td>Profesional</td>
        <td>70</td>
        <td><input type="number" class="nInput" id="profesional" min="0" max="100" value="70" required></td>
        <td class="huruf" id="profesional_huruf">B</td>
        <td id="predikat_profesional">Baik</td>
      </tr>
      <tr>
        <td>3</td>
        <td>Kehadiran</td>
        <td>80</td>
        <td><input type="number" class="nInput" id="kehadiran" min="0" max="100" value="80" required></td>
        <td class="huruf" id="kehadiran_huruf">B</td>
        <td id="predikat_kehadiran">Baik</td>
      </tr>
      <tr>
        <td>4</td>
        <td>Sosial</td>
        <td>70</td>
        <td><input type="number" class="nInput" id="sosial" min="0" max="100" value="70" required></td>
        <td class="huruf" id="sosial_huruf">B</td>
        <td id="predikat_sosial">Baik</td>
      </tr>
      <tr>
        <td>5</td>
        <td>Kepribadian</td>
        <td>70</td>
        <td><input type="number" class="nInput" id="kepribadian" min="0" max="100" value="70" required></td>
        <td class="huruf" id="kepribadian_huruf">B</td>
        <td id="predikat_kepribadian">Baik</td>
      </tr>
      <tr>
        <td colspan="3"><strong>RATA-RATA</strong></td>
        <td id="rata_angka"><strong>72</strong></td>
        <td id="rata_huruf"><strong>B</strong></td>
        <td id="rata_predikat"><strong>Baik</strong></td>
      </tr>
    </table>

    <div class="catatan-section">
      <label for="catatan">Catatan dan Rekomendasi:</label>
      <textarea id="catatan" placeholder="Masukkan catatan penilaian dan rekomendasi untuk pengembangan..."></textarea>
    </div>

    <div class="footer">
      <div class="ttd-row">
        <div class="ttd-block">
          <div>Kepala Sekolah</div>
          <div class="ttd-space"></div>
          <div id="namaKepsek">_________________</div>
        </div>
        <div class="ttd-block">
          <div>Tanggal: <span id="tanggal"></span></div>
          <div style="margin-top: 20px;">Penilai</div>
          <div class="ttd-space"></div>
          <div>Nurachman,S.Pd.I,M.Pd.</div>
        </div>
      </div>
    </div>

    <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; margin-top: 18px;">
      <button type="button" class="export-btn" onclick="exportToPDF()">📄 Cetak PDF</button>
      <button type="button" class="export-btn" onclick="exportToWord()">📝 Export Word</button>
      <button type="button" class="export-btn" onclick="exportToPNG()">🖼️ Export PNG</button>
    </div>
  </form>

  <!-- Tombol untuk membuka rekapitulasi -->
  <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 2px solid #ddd;">
    <button type="button" class="export-btn" onclick="openRekapitulasi()" style="background: #28a745; font-size: 1.1em; padding: 12px 30px;">
      📊 Rekapitulasi Kinerja Seluruh Karyawan
    </button>
  </div>
</div>

<!-- Modal Rekapitulasi -->
<div id="rekapModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000;">
  <div style="background: white; margin: 2% auto; padding: 20px; width: 95%; max-width: 1200px; border-radius: 10px; max-height: 90%; overflow-y: auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #345; padding-bottom: 10px;">
      <h2 style="margin: 0; color: #345;">📊 Rekapitulasi Kinerja Karyawan 2025/2026</h2>
      <button onclick="closeRekapitulasi()" style="background: #dc3545; color: white; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; font-size: 18px;">✕</button>
    </div>
    
    <!-- Form tambah karyawan -->
    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
      <h3 style="margin-top: 0;">➕ Tambah Data Karyawan</h3>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; margin-bottom: 15px;">
        <input type="text" id="newNama" placeholder="Nama Karyawan" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        <input type="text" id="newJabatan" placeholder="Jabatan" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        <select id="newUnit" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
          <option>SMP ISLAM AL-GHOZALI</option>
          <option>SMA ISLAM AL-GHOZALI</option>
        </select>
      </div>
      <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-bottom: 15px;">
        <input type="number" id="newPedagogik" placeholder="Pedagogik" min="0" max="100" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        <input type="number" id="newProfesional" placeholder="Profesional" min="0" max="100" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        <input type="number" id="newKehadiran" placeholder="Kehadiran" min="0" max="100" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        <input type="number" id="newSosial" placeholder="Sosial" min="0" max="100" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        <input type="number" id="newKepribadian" placeholder="Kepribadian" min="0" max="100" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
      </div>
      <button onclick="tambahKaryawan()" style="background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">➕ Tambah Karyawan</button>
    </div>

    <!-- Tabel rekapitulasi -->
    <div style="overflow-x: auto;">
      <table id="rekapTable" style="width: 100%; border-collapse: collapse; font-size: 0.9em;">
        <thead>
          <tr style="background: #345; color: white;">
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">No</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Nama</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Jabatan</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Unit</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Pedagogik</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Profesional</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Kehadiran</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Sosial</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Kepribadian</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Rata-rata</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Predikat</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Aksi</th>
          </tr>
        </thead>
        <tbody id="rekapTableBody">
          <!-- Data akan diisi oleh JavaScript -->
        </tbody>
      </table>
    </div>

    <!-- Statistik -->
    <div style="margin-top: 20px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
      <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; text-align: center;">
        <h4 style="margin: 0; color: #1976d2;">Total Karyawan</h4>
        <div id="totalKaryawan" style="font-size: 2em; font-weight: bold; color: #1976d2;">0</div>
      </div>
      <div style="background: #e8f5e8; padding: 15px; border-radius: 8px; text-align: center;">
        <h4 style="margin: 0; color: #388e3c;">Rata-rata Keseluruhan</h4>
        <div id="rataKeseluruhan" style="font-size: 2em; font-weight: bold; color: #388e3c;">0</div>
      </div>
      <div style="background: #fff3e0; padding: 15px; border-radius: 8px; text-align: center;">
        <h4 style="margin: 0; color: #f57c00;">Perlu Perbaikan</h4>
        <div id="perluPerbaikan" style="font-size: 2em; font-weight: bold; color: #f57c00;">0</div>
      </div>
      <div style="background: #fce4ec; padding: 15px; border-radius: 8px; text-align: center;">
        <h4 style="margin: 0; color: #c2185b;">Kinerja Baik</h4>
        <div id="kinerjaBaik" style="font-size: 2em; font-weight: bold; color: #c2185b;">0</div>
      </div>
    </div>

    <!-- Tombol export rekapitulasi -->
    <div style="text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #ddd;">
      <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
        <button onclick="exportRekapPDF()" style="background: #dc3545; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">📄 Export PDF</button>
        <button onclick="exportRekapWord()" style="background: #0d6efd; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">📝 Export Word</button>
        <button onclick="exportRekapExcel()" style="background: #198754; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">📊 Export Excel</button>
        <button onclick="exportRekapPNG()" style="background: #6f42c1; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">🖼️ Export PNG</button>
      </div>
    </div>
  </div>
</div>

<script>
// ... (script content omitted for brevity, but maintained in original file) ...
</script>
</body>
</html>
`;

const AdminPanel: React.FC<AdminPanelProps> = ({ 
    isOpen, onClose, links, onAddLink, onDeleteLink,
    onBackupData, onRestoreData, onAddTeachers
}) => {
  const [newUserName, setNewUserName] = useState('');
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>('performanceReport');

  const handleAddClick = () => {
    if (newUserName.trim()) {
      onAddLink(newUserName.trim());
      setNewUserName('');
    }
  };

  const handleCopyClick = (url: string) => {
    navigator.clipboard.writeText(url).then(() => {
        setCopiedUrl(url);
        setTimeout(() => setCopiedUrl(null), 2000);
    });
  };
  
  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const text = e.target?.result as string;
            let teachers: string[] = [];

            if (file.name.endsWith('.csv')) {
                teachers = text.split('\n')
                             .map(line => line.split(',')[0].trim())
                             .filter(name => name.length > 0);
                // Simple header check
                if (teachers[0] && (teachers[0].toLowerCase().includes('nama') || teachers[0].toLowerCase().includes('name'))) {
                    teachers.shift();
                }
            } else if (file.name.endsWith('.json')) {
                const data = JSON.parse(text);
                if (Array.isArray(data) && data.every(item => typeof item === 'string')) {
                    teachers = data;
                } else {
                    throw new Error("Format JSON tidak valid. Harusnya berupa array of strings. Contoh: [\"Guru A\", \"Guru B\"]");
                }
            } else {
                throw new Error("Format file tidak didukung. Gunakan .csv atau .json.");
            }
            
            if (teachers.length > 0) {
                onAddTeachers(teachers);
            } else {
                throw new Error("Tidak ada nama guru yang ditemukan dalam file.");
            }

        } catch (err) {
            console.error("Import failed:", err);
            alert(`Gagal mengimpor file: ${(err as Error).message}`);
        }
    };
    reader.readAsText(file);
    event.target.value = ''; // Reset file input
  };


  if (!isOpen) return null;

  const renderContent = () => {
    switch(activeTab) {
        case 'performanceReport':
             return (
                <div className="w-full h-full bg-gray-200">
                    <iframe
                        srcDoc={reportHtml}
                        title="Laporan Kinerja Guru"
                        className="w-full h-full border-0 rounded-md"
                        sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                    />
                </div>
            );
        case 'tracking':
            return (
                <div>
                    <div className="mb-6 border-b pb-6">
                        <h3 className="text-lg font-semibold mb-2">Buat Tautan Pengguna Baru</h3>
                        <div className="flex flex-col sm:flex-row items-center gap-2">
                            <input type="text" value={newUserName} onChange={(e) => setNewUserName(e.target.value)} placeholder="Nama Pengguna (Contoh: Budi)" className="w-full sm:w-auto flex-grow px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                            <button onClick={handleAddClick} className="w-full sm:w-auto px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Buat Link</button>
                        </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-4">Tautan yang Dihasilkan</h3>
                    <div className="overflow-x-auto">
                         <table className="min-w-full divide-y divide-gray-200">
                           <thead className="bg-gray-50">
                             <tr>
                               <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                               <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Link Unik</th>
                               <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Penggunaan</th>
                               <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tindakan</th>
                             </tr>
                           </thead>
                           <tbody className="bg-white divide-y divide-gray-200">
                             {links.map(link => (
                               <tr key={link.id}>
                                 <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{link.userName}</td>
                                 <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><div className="flex items-center space-x-2"><input type="text" readOnly value={link.url} className="w-full bg-gray-100 p-1 rounded border text-xs" /><button onClick={() => handleCopyClick(link.url)} className="text-xs px-2 py-1 rounded bg-gray-200 hover:bg-gray-300">{copiedUrl === link.url ? 'Tersalin!' : 'Salin'}</button></div></td>
                                 <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-bold text-center">{link.usageCount}</td>
                                 <td className="px-6 py-4 whitespace-nowrap text-sm font-medium"><button onClick={() => onDeleteLink(link.id)} className="text-red-600 hover:text-red-900">Hapus</button></td>
                               </tr>
                             ))}
                           </tbody>
                         </table>
                    </div>
                </div>
            );
        case 'dataManagement':
            return (
                 <div>
                    <h3 className="text-lg font-semibold mb-4">Backup & Restore Data</h3>
                    <div className="p-4 border rounded-lg bg-yellow-50 text-yellow-800 mb-6">
                        <p><strong>Penting:</strong> Fitur ini memungkinkan Anda menyimpan semua data aplikasi (riwayat, log, laporan kinerja, dll.) ke dalam satu file. Anda dapat menggunakan file ini untuk memindahkan data ke komputer lain atau sebagai cadangan.</p>
                    </div>
                    <div className="space-y-6">
                        <div>
                            <h4 className="font-semibold text-gray-700">Backup Data</h4>
                            <p className="text-sm text-gray-600 mb-2">Unduh semua data aplikasi ke dalam file JSON.</p>
                            <button onClick={onBackupData} className="w-full sm:w-auto px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Backup Semua Data</button>
                        </div>
                        <div>
                            <h4 className="font-semibold text-gray-700">Restore Data</h4>
                            <p className="text-sm text-gray-600 mb-2">Unggah file backup JSON untuk memulihkan data. <strong className="text-red-600">Awas: Ini akan menimpa semua data yang ada saat ini.</strong></p>
                            <input
                                type="file"
                                accept=".json"
                                onChange={onRestoreData}
                                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                            />
                        </div>
                    </div>
                    <div className="mt-8 pt-8 border-t border-gray-200">
                        <h3 className="text-lg font-semibold mb-4">Impor Data Guru</h3>
                        <div className="p-4 border rounded-lg bg-blue-50 text-blue-800 mb-6">
                            <p><strong>Impor daftar guru secara massal dari file CSV atau JSON.</strong></p>
                            <p className="mt-2 text-sm">
                                <strong>Format CSV:</strong> Satu kolom berisi nama guru, satu nama per baris. Header opsional.<br/>
                                <code className="text-xs block bg-blue-100 p-1 rounded mt-1">
                                    Nama Guru<br/>
                                    Andi Wijaya, S.Pd.<br/>
                                    Budi Santoso, M.Pd.<br/>
                                </code>
                            </p>
                            <p className="mt-2 text-sm">
                                <strong>Format JSON:</strong> Array berisi string nama guru.<br/>
                                <code className="text-xs block bg-blue-100 p-1 rounded mt-1">["Andi Wijaya, S.Pd.", "Budi Santoso, M.Pd."]</code>
                            </p>
                        </div>
                        <input
                            type="file"
                            accept=".csv,.json"
                            onChange={handleFileImport}
                            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                        />
                    </div>
                </div>
            );
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 fade-in">
      <div className="bg-white rounded-lg max-w-5xl w-full p-6 shadow-xl flex flex-col" style={{ height: '90vh' }}>
        <div className="flex items-start justify-between mb-4 flex-shrink-0">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Ruang Admin</h2>
            <p className="text-gray-600">Kelola pengguna, pantau kinerja, dan backup data aplikasi.</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>

        <div className="mb-6 flex-shrink-0">
            <div className="bg-gray-100 p-1.5 rounded-xl flex flex-col sm:flex-row items-center justify-center gap-2">
                 <button
                    onClick={() => setActiveTab('performanceReport')}
                    className={`flex items-center justify-center w-full px-4 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${
                        activeTab === 'performanceReport'
                            ? 'bg-white text-indigo-700 shadow-md'
                            : 'text-gray-600 hover:bg-indigo-50 hover:text-indigo-700'
                    }`}
                >
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a1 1 0 011-1h14a1 1 0 110 2H3a1 1 0 01-1-1z" />
                     </svg>
                    <span>Raport Kinerja Guru</span>
                </button>
                <button
                    onClick={() => setActiveTab('tracking')}
                    className={`flex items-center justify-center w-full px-4 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${
                        activeTab === 'tracking'
                            ? 'bg-white text-indigo-700 shadow-md'
                            : 'text-gray-600 hover:bg-indigo-50 hover:text-indigo-700'
                    }`}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0l-1.5-1.5a2 2 0 112.828-2.828l1.5 1.5 3-3zm-2.828 8.414a2 2 0 012.828 0l3 3a2 2 0 01-2.828 2.828l-3-3a2 2 0 010-2.828zM5 9a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                    <span>Pelacakan Pengguna</span>
                </button>
                <button
                    onClick={() => setActiveTab('dataManagement')}
                    className={`flex items-center justify-center w-full px-4 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${
                        activeTab === 'dataManagement'
                            ? 'bg-white text-indigo-700 shadow-md'
                            : 'text-gray-600 hover:bg-indigo-50 hover:text-indigo-700'
                    }`}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M3 12v3c0 1.657 3.134 3 7 3s7-1.343 7-3v-3c0 1.657-3.134 3-7 3s-7-1.343-7-3z" />
                      <path d="M3 7v3c0 1.657 3.134 3 7 3s7-1.343 7-3V7c0 1.657-3.134 3-7 3S3 8.657 3 7z" />
                      <path d="M10 2C6.134 2 3 3.343 3 5s3.134 3 7 3 7-1.343 7-3-3.134-3-7-3z" />
                    </svg>
                    <span>Manajemen Data</span>
                </button>
            </div>
        </div>

        <div className="flex-grow overflow-y-auto pr-4">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
